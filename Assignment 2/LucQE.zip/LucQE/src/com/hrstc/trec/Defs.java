package com.hrstc.trec;

/**
 * Definitions
 * @author  Neil O. Rouben
 */
public class Defs
{
    public static final String QUERY_ID = "QueryID";
    public static final String ITTERATION = "Itteration";
    public static final String DOCUMENT_NUMBER = "DOCNO";
    public static final String RANK = "RANK";
    public static final String RUN_ID = "RUN_ID";
    public static final String SCORE = "SCORE";
}
